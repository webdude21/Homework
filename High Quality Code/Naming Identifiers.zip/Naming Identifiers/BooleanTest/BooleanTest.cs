﻿namespace BooleanTest
{
    public class BooleanTest
    {
        public static void Main()
        {
            ConsoleOutput.WriteBoolToConsole(false);
        }
    }
}