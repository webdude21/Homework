var divsGeneration = "";

for (var i = 0; i < 60; i++ )
    divsGeneration += "<div>";

for(var j = 0; j < 60; j++)
    divsGeneration += "</div>";

document.write(divsGeneration);